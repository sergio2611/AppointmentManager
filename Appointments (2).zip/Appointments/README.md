# ApptManagerAndroid

Please to use the google maps API function you need to register your application and get a key from google and added in the application manifest.
