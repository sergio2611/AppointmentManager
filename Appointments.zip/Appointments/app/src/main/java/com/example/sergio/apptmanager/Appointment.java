package com.example.sergio.apptmanager;

/**
 * Created by Sergio on 10/10/2017.
 */

public class Appointment {
    public int AppId;
    public String LocationName;
    public String StartTime;
    public String Address;
    public String TransportationType;
    public String TransportationProvider;
    public Boolean Wheelchair;
    public String DoctorName;


    public Appointment(int appId, String locationName, String startTime, String address, String transportationType, String transportationProvider, Boolean wheelchair, String doctorName) {
        AppId = appId;
        LocationName = locationName;
        StartTime = startTime;
        Address = address;
        TransportationType = transportationType;
        TransportationProvider = transportationProvider;
        Wheelchair = wheelchair;
        DoctorName = doctorName;
    }



public String toString()
{
    return this.AppId + ";" + this.LocationName + ";" +this.StartTime + ";" + this.Address + ";"+ this.TransportationType + ";" + this.TransportationProvider + ";" + this.Wheelchair + ";" +this.DoctorName;
}

    public int getAppId() {
        return AppId;
    }

    public void setAppId(int appId) {
        AppId = appId;
    }

    public String getLocationName() {
        return LocationName;
    }

    public void setLocationName(String locationName) {
        LocationName = locationName;
    }

    public String getStartTime() {
        return StartTime;
    }

    public void setStartTime(String startTime) {
        StartTime = startTime;
    }

    public String getAddress() {
        return Address;
    }

    public void setAddress(String address) {
        Address = address;
    }

    public String getTransportationType() {
        return TransportationType;
    }

    public void setTransportationType(String transportationType) {
        TransportationType = transportationType;
    }

    public String getTransportationProvider() {
        return TransportationProvider;
    }

    public void setTransportationProvider(String transportationProvider) {
        TransportationProvider = transportationProvider;
    }

    public Boolean getWheelchair() {
        return Wheelchair;
    }

    public void setWheelchair(Boolean wheelchair) {
        Wheelchair = wheelchair;
    }

    public String getDoctorName() {
        return DoctorName;
    }

    public void setDoctorName(String doctorName) {
        DoctorName = doctorName;
    }
}
